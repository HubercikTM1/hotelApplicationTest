package pl.michal.hotelapplicationtest.domain.model;

public enum ReservationStatusType {
    NEW, IN_PROGRESS, READY, CANCELED
}
